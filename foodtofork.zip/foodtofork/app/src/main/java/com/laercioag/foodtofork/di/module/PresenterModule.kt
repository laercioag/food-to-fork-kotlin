package com.laercioag.foodtofork.di.module

import dagger.Module

@Module
class PresenterModule {

}
