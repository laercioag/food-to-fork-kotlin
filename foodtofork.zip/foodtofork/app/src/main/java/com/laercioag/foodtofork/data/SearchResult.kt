package com.laercioag.foodtofork.data

data class SearchResult(
    val count: Int = 0,
    val recipes: List<Recipe> = listOf()
)