package com.laercioag.foodtofork.di.module

import android.content.Context
import com.laercioag.foodtofork.presentation.app.App
import dagger.Module

@Module
class AppModule {

    fun provideContext(app: App): Context = app.applicationContext

}
